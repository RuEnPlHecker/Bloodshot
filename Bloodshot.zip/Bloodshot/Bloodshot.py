﻿import subprocess #line:1
import sys #line:2
import time #line:3
import re #line:4
def print_red (O0O0O0OOO0OOO0OO0 ):#line:6
    sys .stdout .write ("\033[91m"+O0O0O0OOO0OOO0OO0 +"\033[0m\n")#line:7
def print_blue (OOOO00OOOOO00O0O0 ):#line:9
    sys .stdout .write ("\033[94m"+OOOO00OOOOO00O0O0 +"\033[0m\n")#line:10
banner ="""
████  █      ███   ███  ████  █████ █   █  ███  █████ 
█   █ █     █   █ █   █ █   █ █     █   █ █   █   █   
████  █     █   █ █   █ █████ █████ █████ █   █   █   
█   █ █     █   █ █   █     █ █   █ █   █ █   █   █   
████  █████  ███   ███  ████  █████ █   █  ███    █  
"""#line:18
print_red (banner )#line:19
print_red ("\n\nEnter Skid's IP:")#line:21
ip_address =input ()#line:22
ping_reply_regex =re .compile (r"Reply from (.+): bytes=(\d+) time=(\d+)ms TTL=(\d+)",re .IGNORECASE )#line:24
def ping_ip (O00O00OOO0O0OO0O0 ):#line:26
    OOO0OOOOO0OOO000O =False #line:27
    try :#line:28
        while True :#line:29
            OOOOO0O00O000O0OO =subprocess .run (["ping","-n","1",O00O00OOO0O0OO0O0 ],stdout =subprocess .PIPE ,text =True )#line:30
            OOO0OOO0O0OOOOO00 =ping_reply_regex .search (OOOOO0O00O000O0OO .stdout )#line:31
            if OOO0OOO0O0OOOOO00 :#line:32
                O00000OO00O0O00O0 =OOO0OOO0O0OOOOO00 .group (1 )#line:33
                OO00OO0OOO0O00O0O =OOO0OOO0O0OOOOO00 .group (2 )#line:34
                O00O0O0O00O0O000O =OOO0OOO0O0OOOOO00 .group (3 )#line:35
                OOOO0O0OO0OO00OO0 =OOO0OOO0O0OOOOO00 .group (4 )#line:36
                print_red (f"Reply from {O00000OO00O0O00O0}: bytes={OO00OO0OOO0O00O0O} time={O00O0O0O00O0O000O}ms TTL={OOOO0O0OO0OO00OO0}")#line:37
                if OOO0OOOOO0OOO000O :#line:38
                    print_red ("IP back up.")#line:39
                    OOO0OOOOO0OOO000O =False #line:40
            else :#line:41
                print_blue ("IP IS DOWN")#line:42
                OOO0OOOOO0OOO000O =True #line:43
            time .sleep (1 )#line:44
    except KeyboardInterrupt :#line:45
        print_red ("\nExiting...")#line:46
ping_ip (ip_address )#line:48
